import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/Drawer';

const Drawer = createBottomTabNavigator();

import ArtDesign from './components/Art_design';
import Entypo from './components/Art_design';
import EvilIcons from './components/Art_design';
import Feather from './components/Art_design';
import FontAwesome from './components/Art_design';
import FontAwesome5 from './components/Art_design';

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator>
        <Drawer.Screen name = 'AntDesign' component={ AntDesign }/>
        <Drawer.Screen name = 'Entypo' component={ Entypo }/>
        <Drawer.Screen name = 'EvilIcons' component={ EvilIcons }/>
        <Drawer.Screen name = 'Feather' component={ Feather }/>
        <Drawer.Screen name = 'FontAwesome' component={ FontAwesome }/>
        <Drawer.Screen name = 'FontAwesome5' component={ FontAwesome5}/>
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
/*
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  familia_icones:{
    backgroundColor: 'pink',
    borderRadius: 5,
    whidth:'90%',
    marginBottom: 20,
    padding: 15
  },
  lista_icones:{
    flexDirection: "row",
    marginTop: 20
  },
  familia_titulo:{
    fontSize: 30,
    borderStyle: 'solid',
    borderColor: '#222',
    borderBottomWidth: 2
  },
  espaco_icones:{
    margin: 5
  }
});
*/