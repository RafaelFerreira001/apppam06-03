import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { Entypo, AntDesign, EvilIcons, Feather, FontAwesome, FontAwesome5   } from '@expo/vector-icons';
import { DrawerLayoutAndroid } from 'react-native-web';

export default function App() {
  return (
    <View style={styles.container}>
      {/* 1ª primeira familia */}
      <View style={styles.familia_icones}>
      <Text style={styles.familia_titulo}>Entypo</Text>
      <View style={styles.lista_icones}>
      <Entypo style={styles.espaco_icones} name="500px" size={24} color="green" />
      <Entypo style={styles.espaco_icones} name="500px-with-circle" size={24} color="green" />
      <Entypo style={styles.espaco_icones} name="add-to-list" size={24} color="green" />
      <Entypo style={styles.espaco_icones} name="add-user" size={24} color="green" />
      <Entypo style={styles.espaco_icones} name="address" size={24} color="green" />
      </View>
      </View>
    </View>
  );
}
 /*
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  familia_icones:{
    backgroundColor: 'pink',
    borderRadius: 5,
    whidth:'90%',
    marginBottom: 20,
    padding: 15
  },
  lista_icones:{
    flexDirection: "row",
    marginTop: 20
  },
  familia_titulo:{
    fontSize: 30,
    borderStyle: 'solid',
    borderColor: '#222',
    borderBottomWidth: 2
  },
  espaco_icones:{
    margin: 5
  }
});
*/